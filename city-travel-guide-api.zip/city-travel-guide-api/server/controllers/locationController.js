// server/controllers/locationController.js
const Location = require('../models/Location');
const { getWeatherData, getYelpData } = require('../services/apiService');

// Get all locations
const getLocations = async (req, res) => {
    try {
        const locations = await Location.find();
        res.json(locations);
    } catch (error) {
        res.status(500).json({ message: 'Server Error' });
    }
};

// Create a new location with API data
const createLocation = async (req, res) => {
    const { city } = req.body; // Get city from request body

    try {
        // Fetch weather and Yelp data using the provided city
        const weather = await getWeatherData(city);
        const yelpData = await getYelpData(city);

        // Create a new Location document with the retrieved data
        const newLocation = new Location({ city, weather, yelpData });
        await newLocation.save();

        // Respond with the newly created location
        res.status(201).json(newLocation);
    } catch (error) {
        res.status(400).json({ message: 'Error creating location' });
    }
};

module.exports = { getLocations, createLocation };

