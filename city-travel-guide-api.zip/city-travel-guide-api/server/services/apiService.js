// server/services/apiService.js
const axios = require('axios');
const dotenv = require('dotenv');

dotenv.config();

const getWeatherData = async (city) => {
    const response = await axios.get(`http://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${process.env.OPENWEATHER_API_KEY}`);
    return {
        temperature: response.data.main.temp,
        description: response.data.weather[0].description,
        humidity: response.data.main.humidity,
        windSpeed: response.data.wind.speed,
    };
};

const getYelpData = async (city) => {
    const response = await axios.get(`https://api.yelp.com/v3/businesses/search?location=${city}`, {
        headers: {
            Authorization: `Bearer ${process.env.YELP_API_KEY}`,
        },
    });
    return response.data.businesses.map(business => ({
        name: business.name,
        rating: business.rating,
        location: business.location.address1,
        category: business.categories[0].title,
        url: business.url,
    }));
};

module.exports = { getWeatherData, getYelpData };
