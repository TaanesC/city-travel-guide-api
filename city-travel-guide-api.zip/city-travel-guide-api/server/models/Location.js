// server/models/Location.js
const mongoose = require('mongoose');

const locationSchema = new mongoose.Schema({
    city: { type: String, required: true },
    weather: {
        temperature: Number,
        description: String,
        humidity: Number,
        windSpeed: Number,
    },
    yelpData: [
        {
            name: String,
            rating: Number,
            location: String,
            category: String,
            url: String,
        },
    ],
});

module.exports = mongoose.model('Location', locationSchema);
